function AS_Button_46f8336a66e147c6bfd783187f219b13(eventobject, context) {
    return deleteRowfrm.call(this, context);
}