function initializeTemp02() {
    FlexContainer0a902b761533d41 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100dp",
        "id": "FlexContainer0a902b761533d41",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "skin": "CopyslFbox05802fb50f90243"
    }, {}, {});
    FlexContainer0a902b761533d41.setDefaultUnit(kony.flex.DP);
    var flexAnimate = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "90%",
        "id": "flexAnimate",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flexAnimate.setDefaultUnit(kony.flex.DP);
    var Image01 = new kony.ui.Image2({
        "height": "61dp",
        "id": "Image01",
        "isVisible": true,
        "left": "15dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "22dp",
        "width": "55dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label01 = new kony.ui.Label({
        "id": "Label01",
        "isVisible": true,
        "left": "80dp",
        "skin": "CopyslLabel005bb3505b1c446",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "16dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label02 = new kony.ui.Label({
        "height": "20dp",
        "id": "Label02",
        "isVisible": true,
        "left": "80dp",
        "skin": "CopyslLabel032b28847d26645",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "45dp",
        "width": "220dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label03 = new kony.ui.Label({
        "height": "20dp",
        "id": "Label03",
        "isVisible": true,
        "left": "80dp",
        "skin": "CopyslLabel0a626fe5652a646",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "64dp",
        "width": "220dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Image02 = new kony.ui.Image2({
        "height": "24dp",
        "id": "Image02",
        "isVisible": true,
        "left": "290dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "62dp",
        "width": "20dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label04 = new kony.ui.Label({
        "id": "Label04",
        "isVisible": true,
        "left": "259dp",
        "skin": "CopyslLabel0ec706f81375444",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "19dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flexAnimate.add(
    Image01, Label01, Label02, Label03, Image02, Label04);
    var btnDelete = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "100%",
        "id": "btnDelete",
        "isVisible": true,
        "left": "0dp",
        "onClick": AS_Button_46f8336a66e147c6bfd783187f219b13,
        "skin": "CopyslButtonGlossBlue0d2925f66d9f64f",
        "text": "Button",
        "top": "0dp",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnCancel = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "100%",
        "id": "btnCancel",
        "isVisible": true,
        "left": "0dp",
        "onClick": AS_Button_0c733f8e4cc04604836c537b3be27ae3,
        "skin": "CopyslButtonGlossBlue0ad5f6725f90d4f",
        "text": "btnCancel",
        "top": "0dp",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0a902b761533d41.add(
    flexAnimate, btnDelete, btnCancel);
}