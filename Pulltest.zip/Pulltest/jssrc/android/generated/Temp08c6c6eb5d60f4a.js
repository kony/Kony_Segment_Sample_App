function initializeTemp08c6c6eb5d60f4a() {
    FlexContainer0b90d9209818248 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "30%",
        "id": "FlexContainer0b90d9209818248",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "skin": "CopyslFbox04c2bea65477f47"
    }, {}, {});
    FlexContainer0b90d9209818248.setDefaultUnit(kony.flex.DP);
    var flexAnimate = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "90%",
        "id": "flexAnimate",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox048f643485f3347",
        "top": "5dp",
        "width": "100%"
    }, {}, {});
    flexAnimate.setDefaultUnit(kony.flex.DP);
    var Label0c43a02f9104041 = new kony.ui.Label({
        "height": "20.83%",
        "id": "Label0c43a02f9104041",
        "isVisible": true,
        "left": "100dp",
        "skin": "slLabel",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10dp",
        "width": "30%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Image0c432213ca7bf45 = new kony.ui.Image2({
        "height": "50dp",
        "id": "Image0c432213ca7bf45",
        "isVisible": true,
        "left": "15dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "23dp",
        "width": "55dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0546113be87c54e = new kony.ui.Label({
        "id": "Label0546113be87c54e",
        "isVisible": true,
        "left": "88dp",
        "skin": "slLabel",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "45dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Image038a3bdc39a1d4e = new kony.ui.Image2({
        "height": "75dp",
        "id": "Image038a3bdc39a1d4e",
        "isVisible": true,
        "left": "223dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "19dp",
        "width": "120dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flexAnimate.add(
    Label0c43a02f9104041, Image0c432213ca7bf45, Label0546113be87c54e, Image038a3bdc39a1d4e);
    var btnDelete = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "100%",
        "id": "btnDelete",
        "isVisible": true,
        "left": "0dp",
        "onClick": AS_Button_9ee031c97cad4cc09007eaaba67bdfe2,
        "skin": "CopyslButtonGlossBlue0bf99bc07a0b74c",
        "text": "Delete",
        "top": "0dp",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnCancel = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "100%",
        "id": "btnCancel",
        "isVisible": true,
        "left": "0dp",
        "onClick": AS_Button_83b5529a3b7e435db1c3b8eac81d2770,
        "skin": "CopyslButtonGlossBlue0299c4c5dd96146",
        "text": "Cancel",
        "top": "0dp",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0b90d9209818248.add(
    flexAnimate, btnDelete, btnCancel);
}