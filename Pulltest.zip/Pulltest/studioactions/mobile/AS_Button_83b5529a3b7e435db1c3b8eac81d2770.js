function AS_Button_83b5529a3b7e435db1c3b8eac81d2770(eventobject, context) {
    return cancelDeleteOld.call(this);
}