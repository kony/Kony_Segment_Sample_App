function addWidgetsMailForm() {
    MailForm.setDefaultUnit(kony.flex.DP);
    var MailRows = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Image01": "icon1.png",
            "Image02": "option1.png",
            "Label01": "Fashionista",
            "Label02": "Choose your credit card",
            "Label03": "Choose your credit card",
            "Label04": "Feb 25",
            "btnCancel": "Cancel",
            "btnDelete": "Delete"
        }, {
            "Image01": "icon3.png",
            "Image02": "option1.png",
            "Label01": "Pooja Property",
            "Label02": "your Ad expires today",
            "Label03": "To ensure delivery to your",
            "Label04": "Feb 25",
            "btnCancel": "Cancel",
            "btnDelete": "Delete"
        }, {
            "Image01": "icon2.png",
            "Image02": "option1.png",
            "Label01": "gauhar Funds",
            "Label02": "Saving is just a tap away",
            "Label03": "Logo OLA share OLA",
            "Label04": "Feb 24",
            "btnCancel": "Cancel",
            "btnDelete": "Delete"
        }, {
            "Image01": "icon4.png",
            "Image02": "option1.png",
            "Label01": "500Px",
            "Label02": "That's amazing?",
            "Label03": "That's amazing 500 dollars",
            "Label04": "Feb 24",
            "btnCancel": "Cancel",
            "btnDelete": "Delete"
        }, {
            "Image01": "icon3.png",
            "Image02": "option1.png",
            "Label01": "Pranay Enterprise",
            "Label02": "Best deals for limited time",
            "Label03": "Report Spam|view in browser",
            "Label04": "Feb 24",
            "btnCancel": "Cancel",
            "btnDelete": "Delete"
        }, {
            "Image01": "icon2.png",
            "Image02": "option1.png",
            "Label01": "Ganga Property",
            "Label02": "Neha vashish has viewed",
            "Label03": "To ensure delivery to your",
            "Label04": "Feb 23",
            "btnCancel": "Cancel",
            "btnDelete": "Delete"
        }, {
            "Image01": "icon1.png",
            "Image02": "option1.png",
            "Label01": "Fahan Property",
            "Label02": "Sanchita jha has viewed",
            "Label03": "To ensure delivery to your",
            "Label04": "Feb 23",
            "btnCancel": "Cancel",
            "btnDelete": "Delete"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "MailRows",
        "isVisible": true,
        "left": "0%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg0fd2ceaceefc147",
        "rowTemplate": FlexContainer0a902b761533d41,
        "scrollingEvents": {
            "onPull": AS_Segment_99ddf23497b848059ddefb424f4c6950
        },
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "c7c7c700",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "10%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer0a902b761533d41": "FlexContainer0a902b761533d41",
            "Image01": "Image01",
            "Image02": "Image02",
            "Label01": "Label01",
            "Label02": "Label02",
            "Label03": "Label03",
            "Label04": "Label04",
            "btnCancel": "btnCancel",
            "btnDelete": "btnDelete",
            "flexAnimate": "flexAnimate"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Header = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "60dp",
        "id": "Header",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0d188a419392548",
        "top": "0dp",
        "width": "99.41%",
        "zIndex": 1
    }, {}, {});
    Header.setDefaultUnit(kony.flex.DP);
    var Image0866843212c6c42 = new kony.ui.Image2({
        "height": "29dp",
        "id": "Image0866843212c6c42",
        "isVisible": true,
        "left": "33dp",
        "skin": "slImage",
        "src": "icon5.png",
        "top": "17dp",
        "width": "30dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label08317eac0509449 = new kony.ui.Label({
        "id": "Label08317eac0509449",
        "isVisible": true,
        "left": "90dp",
        "skin": "CopyslLabel0f87afc32a2594f",
        "text": "Primary",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "20dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Image0841e68ee9d974a = new kony.ui.Image2({
        "height": "30dp",
        "id": "Image0841e68ee9d974a",
        "isVisible": true,
        "left": "280dp",
        "skin": "slImage",
        "src": "zoomout.png",
        "top": "17dp",
        "width": "33dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    Header.add(
    Image0866843212c6c42, Label08317eac0509449, Image0841e68ee9d974a);
    MailForm.add(
    MailRows, Header);
};

function MailFormGlobals() {
    MailForm = new kony.ui.Form2({
        "addWidgets": addWidgetsMailForm,
        "enabledForIdleTimeout": false,
        "id": "MailForm",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "postShow": AS_Form_6b0745cda92c4eb7ab80a9990ce86c37,
        "preShow": AS_Form_2ea67c959528482596fa8722a2971692,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};