function AS_Button_9ee031c97cad4cc09007eaaba67bdfe2(eventobject, context) {
    return deleteRowfrm.call(this, context);
}