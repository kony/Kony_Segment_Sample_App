function AS_Form_21e7252e871946b48d20c120e15a516b(eventobject) {
    return GestueHandlerfrm2.call(this);
}