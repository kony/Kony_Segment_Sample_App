function AS_Form_2ea67c959528482596fa8722a2971692(eventobject) {
    return GestueHandlerfrm2.call(this);
}