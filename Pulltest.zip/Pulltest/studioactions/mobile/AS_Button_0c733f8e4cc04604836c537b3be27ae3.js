function AS_Button_0c733f8e4cc04604836c537b3be27ae3(eventobject, context) {
    return cancelDelete.call(this, eventobject);
}