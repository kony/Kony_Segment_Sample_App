//actions.js file 
function AS_Button_0c733f8e4cc04604836c537b3be27ae3(eventobject, context) {
    return cancelDelete.call(this, eventobject);
}
function AS_Button_46f8336a66e147c6bfd783187f219b13(eventobject, context) {
    return deleteRowfrm.call(this, context);
}
function AS_Button_83b5529a3b7e435db1c3b8eac81d2770(eventobject, context) {
    return cancelDeleteOld.call(this);
}
function AS_Button_9ee031c97cad4cc09007eaaba67bdfe2(eventobject, context) {
    return deleteRowfrm.call(this, context);
}
function AS_Form_0befce63b2d14e82acf15c8d967f3dbe(eventobject) {}
function AS_Form_21e7252e871946b48d20c120e15a516b(eventobject) {
    return GestueHandlerfrm2.call(this);
}
function AS_Form_2ea67c959528482596fa8722a2971692(eventobject) {
    return GestueHandlerfrm2.call(this);
}
function AS_Form_6b0745cda92c4eb7ab80a9990ce86c37(eventobject) {}
function AS_Segment_99ddf23497b848059ddefb424f4c6950(eventobject) {
    //alert("why did u pull me down");
}