function AS_Segment_99ddf23497b848059ddefb424f4c6950(eventobject) {
    //alert("why did u pull me down");
}