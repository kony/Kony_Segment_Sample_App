function initializeTemp01() {
    flexAnimate = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100dp",
        "id": "flexAnimate",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox001e6f2ef860444"
    }, {}, {});
    flexAnimate.setDefaultUnit(kony.flex.DP);
    var Image01 = new kony.ui.Image2({
        "height": "61dp",
        "id": "Image01",
        "isVisible": true,
        "left": "15dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "22dp",
        "width": "55dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label01 = new kony.ui.Label({
        "id": "Label01",
        "isVisible": true,
        "left": "80dp",
        "skin": "CopyslLabel0ff9d701ce4f84d",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "16dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label02 = new kony.ui.Label({
        "height": "20dp",
        "id": "Label02",
        "isVisible": true,
        "left": "80dp",
        "skin": "CopyslLabel0fe34e5b567fc41",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "45dp",
        "width": "220dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label03 = new kony.ui.Label({
        "height": "20dp",
        "id": "Label03",
        "isVisible": true,
        "left": "80dp",
        "skin": "CopyslLabel05bfe6057fe4944",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "64dp",
        "width": "220dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Image02 = new kony.ui.Image2({
        "height": "24dp",
        "id": "Image02",
        "isVisible": true,
        "left": "290dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "62dp",
        "width": "20dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label04 = new kony.ui.Label({
        "id": "Label04",
        "isVisible": true,
        "left": "259dp",
        "skin": "CopyslLabel06b7359c289e642",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "19dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flexAnimate.add(
    Image01, Label01, Label02, Label03, Image02, Label04);
}